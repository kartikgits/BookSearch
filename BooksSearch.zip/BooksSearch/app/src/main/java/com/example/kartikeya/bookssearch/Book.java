package com.example.kartikeya.bookssearch;

/**
 * Created by Kartikeya on 7/24/2017.
 */

public class Book {
    private String title;
    private String author;
    private int pageCount;

    public Book(String mTitle, String mAuthor, int mPageCount){
        title = mTitle;
        author = mAuthor;
        pageCount = mPageCount;
    }

    public String getTitle(){ return title; }

    public String getAuthor(){ return author; }

    public int getPageCount(){ return pageCount; }
}
