package com.example.kartikeya.bookssearch;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Loader;
import android.media.Image;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class BookActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Book>> {

    private static final String LOG_TAG = "BookActivity";

    /**
     * Constant value for the book loader ID. We can choose any integer.
     * This really only comes into play if you're using multiple loaders.
     */
    private static final int BOOK_LOADER_ID = 1;

    //This will receive the user search query from SearchActivity.java
    final static String QUERY = "";

    /**
     *Adapter for the list of books.
     */
    private BookAdapter mAdapter;

    /**
     *to be shown while data loading
     */
    private ProgressBar progressBar;

    /**
     * Url for data request.
     */
    private String requestUrl = "https://www.googleapis.com/books/v1/volumes?q=";

    /**
     * User search query.
     */
    private String query;

    /**
     * TextView to be displayed on an empty list.
     */
    private TextView mEmptyStateTextView;

    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);
        Log.i(LOG_TAG, "BookList Layout set.");

        listView = (ListView)findViewById(R.id.list);
        progressBar = (ProgressBar)findViewById(R.id.loading_spinner);

        //Get the search keyword from SearchActivity.java
        query = getIntent().getStringExtra(QUERY);
        requestUrl = requestUrl + query;

        //Initialize the adapter with new empty list of books
        mAdapter = new BookAdapter(this,new ArrayList<Book>());
        listView.setAdapter(mAdapter);

        //Show the progress bar unless the load is finished
        progressBar.setVisibility(View.VISIBLE);
        listView.setVisibility(View.INVISIBLE);

        //start the Loader to load the required data
        getLoaderManager().initLoader(BOOK_LOADER_ID,null,this);
    }

    @Override
    public Loader<List<Book>> onCreateLoader(int i, Bundle bundle) {
        Log.i(LOG_TAG,"onCreateLoader called.");
        return new BookLoader(this, requestUrl);
    }

    @Override
    public void onLoadFinished(Loader<List<Book>> loader, List<Book> books) {
        //After the load is finished, we need to remove the progress bar.
        progressBar = (ProgressBar) findViewById(R.id.loading_spinner);
        progressBar.setVisibility(View.INVISIBLE);

        Log.i(LOG_TAG,"onLoadFinished called.");

        //Clear the adapter of previous book data.
        mAdapter.clear();

        //If there is a valid list of Books, then add them to the adapter's data set.
        //This will trigger the ListView to update.
        if (books!=null && !books.isEmpty()){
            //To check the empty view behaviour, temporarily comment out
            //the @link(mAdapter.addAll(earthquakes);).
            //This will pretend like that there were no earthquakes at the server.
            mAdapter.addAll(books);
            mAdapter.notifyDataSetChanged();
            listView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<Book>> loader) {
        Log.i(LOG_TAG,"onLoaderReset called.");
        //Loader reset, so we can clear our existing data.
        mAdapter.clear();
    }
}