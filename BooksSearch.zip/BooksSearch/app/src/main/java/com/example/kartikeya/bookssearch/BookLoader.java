package com.example.kartikeya.bookssearch;

import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.Loader;
import android.util.Log;

import java.util.List;

/**
 * Created by Kartikeya on 10/27/2017.
 */

public class BookLoader extends AsyncTaskLoader<List<Book>> {

    final static private String LOG_TAG = "BookLoader";

    private String url = null;

    public BookLoader(Context context, String mUrl) {
        super(context);
        Log.i(LOG_TAG,"Default constructor called.");
        url = mUrl;
    }

    @Override
    protected void onStartLoading(){
        Log.i(LOG_TAG,"onStartLoading called.");
        forceLoad();
    }

    @Override
    public List<Book> loadInBackground(){
        Log.i(LOG_TAG,"loadInBackground called.");
        //Don't perform the request if there is no URL.
        if (url == null){
            return null;
        }
        List<Book> books = QueryUtils.fetchBookData(url);
        return books;
    }
}
