package com.example.kartikeya.bookssearch;

/**
 * Created by Kartikeya on 7/27/2017.
 */

import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Helper methods related to getting data from the Google Books servers.
 */
public final class QueryUtils{
    private static final String LOG_TAG = "QueryUtils";

    /**
     * Creating a private constructor as this class will be used only to hold variables
     * regarding data fetch from Google Books servers.
     */
    private QueryUtils(){
    }

    /**
     * Return the list of {@link Book} objects that has been built up from
     * parsing the JSON response.
     */
    private static List<Book> extractFeatureFromJson(String bookJSON){
        //If the JSON string is null or empty, then return early
        if (TextUtils.isEmpty(bookJSON)){
            return null;
        }

        //Create an ArrayList that we can start adding books to
        List<Book> books = new ArrayList<>();

        /**
         * Try to parse the JSON response. If there's a problem with parsing,
         * an exception will be thrown. Catch this exception so it that it doesn't cause any problems.
         */
        try {
            JSONObject baseJSONObject = new JSONObject(bookJSON);
            //Extract the JSONArray associated with the key "items".
            JSONArray bookArray = baseJSONObject.getJSONArray("items");

            //For each book in the bookArray, create a book object.
            for (int i = 0; i < bookArray.length(); i++){
                //Get the book at current position 'i'
                JSONObject currentBook = bookArray.getJSONObject(i);

                JSONObject volumeInfo = currentBook.getJSONObject("volumeInfo");

                String title = volumeInfo.getString("title");

                JSONArray authors = volumeInfo.getJSONArray("authors");

                String author = authors.getString(0);

                int pageCount = volumeInfo.getInt("pageCount");

                //Create a new @link {Book} object with title, author and
                //pageCount from JSON.
                Book book = new Book(title, author, pageCount);

                //Add this new book to the list of books.
                books.add(book);
            }
        } catch (JSONException e){
            Log.e("QueryUtils", "Problem parsing the book JSON results", e);
        }
        //Return the list of books.
        return books;
    }

    /**
     * Query the Google Books data set and return a list of {@link Book} objects.
     */
    public static List<Book> fetchBookData(String requestUrl){
        Log.i(LOG_TAG,"fetchBookData called!");

        //Create URL object
        URL url = createUrl(requestUrl);

        // Perform HTTP request to the URL and receive a JSON response back
        String jsonResponse = null;
        try {
            jsonResponse = makeHttpRequest(url);
        } catch (IOException e) {
            Log.e("QueryUtils", "Problem making the HTTP request.", e);
        }

        List<Book> books = extractFeatureFromJson(jsonResponse);
        return books;
    }

    /**
     *Make an HTTP request to the given URL and return JSON string response.
     */
    private static String makeHttpRequest(URL url) throws IOException {
        String jsonResponse = "";

        //If url is null, return early.
        if (url == null){
            return null;
        }

        HttpURLConnection urlConnection = null;
        InputStream istream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(10000);
            urlConnection.setConnectTimeout(15000);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            /**
             * If the request was successful (response code 200),
             * read the input stream and parse the response.
             */
            if (urlConnection.getResponseCode() == 200) {
                istream = urlConnection.getInputStream();
                jsonResponse = readFromStream(istream);
            } else {
                Log.e(LOG_TAG, "Error Response code: " + urlConnection.getResponseCode());
            }
        } catch (IOException e){
            Log.e(LOG_TAG, "Problem retrieving the Books JSON response", e);
        } finally {
            if (urlConnection != null){
                urlConnection.disconnect();
            }
            if (istream != null){
                // Closing the input stream could throw an IOException, which is why
                // the makeHttpRequest(URL url) method signature specifies than an IOException
                // could be thrown.
                istream.close();
            }
        }
        return jsonResponse;
    }

    /**
     * Convert the {@link InputStream} into a String which contains the
     * whole JSON response from the server.
     */
    private static String readFromStream(InputStream istream) throws IOException{
        StringBuilder output = new StringBuilder();
        if (istream != null){
            InputStreamReader iStreamReader = new InputStreamReader(istream, Charset.forName("UTF-8"));
            BufferedReader bufferedReader = new BufferedReader(iStreamReader);
            String line = bufferedReader.readLine();
            while (line != null){
                output.append(line);
                line = bufferedReader.readLine();
            }
        }
        return output.toString();
    }

    /**
     * Returns new URL object from the given String url.
     */
    private static URL createUrl(String stringUrl) {
        URL url = null;
        try {
            url = new URL(stringUrl);
        } catch (MalformedURLException e){
            Log.e(LOG_TAG, "Problem building the Url. ",e);
        }
        return url;
    }
}
