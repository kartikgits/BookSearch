package com.example.kartikeya.bookssearch;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by Kartikeya on 10/28/2017.
 */

public class SearchActivity extends AppCompatActivity {

    private static final String LOG_TAG = "SearchActivity";
    private ImageView searchImage;
    private EditText searchEditText;

    //String entered by the user in the search bar.
    private String searchString;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Log.i(LOG_TAG,"Search Layout set.");

        searchEditText = (EditText)findViewById(R.id.search_bar);
        searchImage = (ImageView)findViewById(R.id.search_button);

        searchImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(LOG_TAG,"Search button pressed.");
                searchString = searchEditText.getText().toString();

                //Check whether user has entered a text or not
                if ((searchString == null) || TextUtils.isEmpty(searchString)){
                    Toast.makeText(SearchActivity.this, "Please enter search keyword", Toast.LENGTH_LONG).show();
                    return;
                }

                //Check network connectivity, then start the BookActivity (if connected)
                startSearching();
            }
        });
    }

    private void startSearching(){
        if (checkNetworkStatus()){
            //Start the BookActivity passing the finalString of the user input and the user selection
            Log.i(LOG_TAG,"Calling BookActivity");
            Intent intent = new Intent(this, BookActivity.class);
            intent.putExtra(BookActivity.QUERY, searchString);
            startActivity(intent);
        }
        else {
            Toast.makeText(SearchActivity.this,"No Internet Connection",Toast.LENGTH_LONG).show();
        }
    }

    //Check network connection, return true if connected.
    private boolean checkNetworkStatus(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }
}
